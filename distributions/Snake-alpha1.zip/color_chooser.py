from tkinter import colorchooser

print(colorchooser.askcolor())